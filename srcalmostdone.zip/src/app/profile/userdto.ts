export class UserDto{
    userId!:number;
	firstName!:string;
	lastName!:string;
	mobileNumber!:string;
    age!:number;
	email!:string;
	userRole!:string;
}