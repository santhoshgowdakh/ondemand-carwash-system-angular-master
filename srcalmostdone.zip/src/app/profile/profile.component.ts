import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationResponse } from '../user/AuthenticationResponse';
import { UserModel } from '../user/user.model';
import { UserService } from '../user/user.service';
import { UserDto } from './userdto';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  user!:UserDto;

  constructor(private userService: UserService,private router:Router) { }
  authenticationResponse!:AuthenticationResponse
  ngOnInit(): void {
    this.authenticationResponse=JSON.parse(String(window.localStorage.getItem("loggedInUser")));
    if(this.authenticationResponse==null){
      this.router.navigate(['login']);
    }
    this.userService.getUserById(this.authenticationResponse.userId).subscribe((user) => {
      console.log("User Details ");
      console.log(user);
      this.user = user;
    });
  }

}
