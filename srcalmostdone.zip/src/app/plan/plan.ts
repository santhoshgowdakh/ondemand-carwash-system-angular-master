export class Plan{
    planId!:number;
	planName!:string;
	planDescription!:string ;
	carType!:string;
	price!:number;
}