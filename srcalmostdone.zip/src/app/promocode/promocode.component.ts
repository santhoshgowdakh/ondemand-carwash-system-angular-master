import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promocode',
  templateUrl: './promocode.component.html',
  styleUrls: ['./promocode.component.css']
})
export class PromocodeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
