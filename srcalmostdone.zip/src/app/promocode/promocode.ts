export class Promocode{
	promocode!:string;
	promocodeDescription!:string ;
	discount!:number;
}