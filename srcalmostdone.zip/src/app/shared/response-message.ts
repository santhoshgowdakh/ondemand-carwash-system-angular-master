export class ResponseMessage{
    message!:string;
}