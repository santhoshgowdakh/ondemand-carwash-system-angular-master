export class Address{
    addressId!:number;
    addressName!:string;
    street!:string;
    city!:string;
    state!:string;
    pincode!:number;
    userId!:number;
}