export class AcceptOrderRequest{
    orderId!:number;
	washerId!:number;
	scheduledDate!:Date;
}