export class Car{
    carId!:number;
    userId!:number;
	carImage!:string;
	carRegistrationNumber!:string;
	carLocation!:string;
	carColor!:string;
	carBrand!:string;
	carModel!:string;
    carType!:string;
}