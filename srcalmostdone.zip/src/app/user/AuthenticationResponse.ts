export class AuthenticationResponse{
    userId!:number;
    jwt!:string;
    userRole!:string;
}