export class AuthenticationRequest{
    userName!:string;
    password!:string;
}