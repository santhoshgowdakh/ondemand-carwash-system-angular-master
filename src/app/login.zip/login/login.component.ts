import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationResponse } from '../user/AuthenticationResponse';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router,private userService:UserService) { }
  loginForm!:FormGroup;
  user!:string;
  ngOnInit(): void {
    const userId=window.localStorage.getItem('userId');
if(this.user!=null){
  this.router.navigate(['productlist']);
}
this.loginForm= new FormGroup({
  userName: new FormControl('', Validators.required),
  password: new FormControl('',Validators.required),
});
  }
authenticationResponse!:AuthenticationResponse;
  login(){
    console.log(this.loginForm.value);
    this.userService.logIn(this.loginForm.value).subscribe
    (data => {
      // if(data instanceof ApiResponse){
      //   this.apiResponse=data;
      //   alert(this.apiResponse.message);
      // }
      if(data instanceof AuthenticationResponse){
        this.authenticationResponse=data;
      }
        window.localStorage.setItem('loggedInUser',JSON.stringify(data));
       // this.userType=data.userType;
       this.router.navigate(['plan']);
       window.location.reload();

    });
  }
  get userName(){
    return this.loginForm.get('userName');
   }
   get password(){
    return this.loginForm.get('password');
   }
}
