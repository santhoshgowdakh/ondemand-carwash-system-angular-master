export class AuthenticationResponse{
    userId!:Number;
    jwt!:string;
    userRole!:string;
}